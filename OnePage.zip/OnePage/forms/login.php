<?php
session_start();

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "myhealthfirst";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Prepared statement to prevent SQL injection
    $stmt = $conn->prepare("SELECT id, password FROM users WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $stmt->store_result();
    
    if ($stmt->num_rows > 0) {
        $stmt->bind_result($id, $password);
        $stmt->fetch();

        // Verify password
        if (password_verify($password)) {
            // Password is correct, start a session
            $_SESSION['userid'] = $id;
            $_SESSION['username'] = $username;

            echo "<script type='text/javascript'>
                alert('Login successful!');
                window.location.href = '../index.html';
            </script>";
        } else {
            echo "<script type='text/javascript'>
                alert('Invalid password.');
                window.location.href = '../login.php';
            </script>";
        }
    } else {
        echo "<script type='text/javascript'>
            alert('No user found with that username.');
            window.location.href = '../login.php';
        </script>";
    }

    $stmt->close();
}
$conn->close();
?>
